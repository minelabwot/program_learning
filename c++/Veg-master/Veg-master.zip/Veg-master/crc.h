#ifndef CRC_H
#define CRC_H

unsigned short int cal_crc(unsigned char *ptr, unsigned int len);

#endif
